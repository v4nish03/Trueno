--
-- PostgreSQL database dump
--

\restrict elclamNA7HNSkdTlaKXV1FBwWFw78Fe1xyx6hHYhxBSMFC7GudqPAgd7deA1oKc

-- Dumped from database version 18.2
-- Dumped by pg_dump version 18.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: estadoturnoenum; Type: TYPE; Schema: public; Owner: v4
--

CREATE TYPE public.estadoturnoenum AS ENUM (
    'abierto',
    'cerrado'
);


ALTER TYPE public.estadoturnoenum OWNER TO v4;

--
-- Name: estadoventaenum; Type: TYPE; Schema: public; Owner: v4
--

CREATE TYPE public.estadoventaenum AS ENUM (
    'abierta',
    'completa',
    'anulada'
);


ALTER TYPE public.estadoventaenum OWNER TO v4;

--
-- Name: metodopagoenum; Type: TYPE; Schema: public; Owner: v4
--

CREATE TYPE public.metodopagoenum AS ENUM (
    'efectivo',
    'qr'
);


ALTER TYPE public.metodopagoenum OWNER TO v4;

--
-- Name: motivomovimientoenum; Type: TYPE; Schema: public; Owner: v4
--

CREATE TYPE public.motivomovimientoenum AS ENUM (
    'compra',
    'venta',
    'devolucion',
    'stock_inicial',
    'correccion'
);


ALTER TYPE public.motivomovimientoenum OWNER TO v4;

--
-- Name: tipomovimientoenum; Type: TYPE; Schema: public; Owner: v4
--

CREATE TYPE public.tipomovimientoenum AS ENUM (
    'ingreso',
    'salida',
    'ajuste'
);


ALTER TYPE public.tipomovimientoenum OWNER TO v4;

--
-- Name: tipoventaenum; Type: TYPE; Schema: public; Owner: v4
--

CREATE TYPE public.tipoventaenum AS ENUM (
    'normal',
    'sin_stock'
);


ALTER TYPE public.tipoventaenum OWNER TO v4;

--
-- Name: ubicacionproducto; Type: TYPE; Schema: public; Owner: v4
--

CREATE TYPE public.ubicacionproducto AS ENUM (
    'TIENDA',
    'BODEGA'
);


ALTER TYPE public.ubicacionproducto OWNER TO v4;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: configuracion; Type: TABLE; Schema: public; Owner: v4
--

CREATE TABLE public.configuracion (
    id integer NOT NULL,
    clave character varying(100) NOT NULL,
    valor text,
    descripcion character varying(255),
    activo boolean
);


ALTER TABLE public.configuracion OWNER TO v4;

--
-- Name: configuracion_id_seq; Type: SEQUENCE; Schema: public; Owner: v4
--

CREATE SEQUENCE public.configuracion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.configuracion_id_seq OWNER TO v4;

--
-- Name: configuracion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: v4
--

ALTER SEQUENCE public.configuracion_id_seq OWNED BY public.configuracion.id;


--
-- Name: movimientos_inventario; Type: TABLE; Schema: public; Owner: v4
--

CREATE TABLE public.movimientos_inventario (
    id integer NOT NULL,
    producto_id integer NOT NULL,
    tipo public.tipomovimientoenum NOT NULL,
    motivo public.motivomovimientoenum NOT NULL,
    cantidad integer NOT NULL,
    referencia_id integer,
    fecha timestamp with time zone DEFAULT now()
);


ALTER TABLE public.movimientos_inventario OWNER TO v4;

--
-- Name: movimientos_inventario_id_seq; Type: SEQUENCE; Schema: public; Owner: v4
--

CREATE SEQUENCE public.movimientos_inventario_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.movimientos_inventario_id_seq OWNER TO v4;

--
-- Name: movimientos_inventario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: v4
--

ALTER SEQUENCE public.movimientos_inventario_id_seq OWNED BY public.movimientos_inventario.id;


--
-- Name: productos; Type: TABLE; Schema: public; Owner: v4
--

CREATE TABLE public.productos (
    id integer NOT NULL,
    codigo character varying(50) NOT NULL,
    nombre character varying(150) NOT NULL,
    descripcion text,
    precio1 double precision NOT NULL,
    precio2 double precision,
    precio3 double precision,
    precio4 double precision,
    stock integer NOT NULL,
    stock_minimo integer NOT NULL,
    ventas_sin_stock integer NOT NULL,
    ubicacion public.ubicacionproducto NOT NULL,
    activo boolean NOT NULL,
    fecha_creacion timestamp with time zone DEFAULT now(),
    fecha_edicion timestamp with time zone DEFAULT now()
);


ALTER TABLE public.productos OWNER TO v4;

--
-- Name: productos_id_seq; Type: SEQUENCE; Schema: public; Owner: v4
--

CREATE SEQUENCE public.productos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.productos_id_seq OWNER TO v4;

--
-- Name: productos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: v4
--

ALTER SEQUENCE public.productos_id_seq OWNED BY public.productos.id;


--
-- Name: recibos; Type: TABLE; Schema: public; Owner: v4
--

CREATE TABLE public.recibos (
    id integer NOT NULL,
    venta_id integer NOT NULL,
    codigo_qr character varying NOT NULL,
    fecha_impresion timestamp with time zone DEFAULT now()
);


ALTER TABLE public.recibos OWNER TO v4;

--
-- Name: recibos_id_seq; Type: SEQUENCE; Schema: public; Owner: v4
--

CREATE SEQUENCE public.recibos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recibos_id_seq OWNER TO v4;

--
-- Name: recibos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: v4
--

ALTER SEQUENCE public.recibos_id_seq OWNED BY public.recibos.id;


--
-- Name: turnos_caja; Type: TABLE; Schema: public; Owner: v4
--

CREATE TABLE public.turnos_caja (
    id integer NOT NULL,
    fecha_apertura timestamp with time zone DEFAULT now(),
    fecha_cierre timestamp with time zone,
    monto_inicial double precision,
    estado public.estadoturnoenum
);


ALTER TABLE public.turnos_caja OWNER TO v4;

--
-- Name: turnos_caja_id_seq; Type: SEQUENCE; Schema: public; Owner: v4
--

CREATE SEQUENCE public.turnos_caja_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.turnos_caja_id_seq OWNER TO v4;

--
-- Name: turnos_caja_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: v4
--

ALTER SEQUENCE public.turnos_caja_id_seq OWNED BY public.turnos_caja.id;


--
-- Name: venta_productos; Type: TABLE; Schema: public; Owner: v4
--

CREATE TABLE public.venta_productos (
    id integer NOT NULL,
    venta_id integer NOT NULL,
    producto_id integer NOT NULL,
    cantidad integer NOT NULL,
    precio_unitario double precision NOT NULL
);


ALTER TABLE public.venta_productos OWNER TO v4;

--
-- Name: venta_productos_id_seq; Type: SEQUENCE; Schema: public; Owner: v4
--

CREATE SEQUENCE public.venta_productos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.venta_productos_id_seq OWNER TO v4;

--
-- Name: venta_productos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: v4
--

ALTER SEQUENCE public.venta_productos_id_seq OWNED BY public.venta_productos.id;


--
-- Name: ventas; Type: TABLE; Schema: public; Owner: v4
--

CREATE TABLE public.ventas (
    id integer NOT NULL,
    fecha timestamp with time zone DEFAULT now(),
    total double precision,
    tipo public.tipoventaenum,
    metodo_pago public.metodopagoenum,
    estado public.estadoventaenum,
    turno_id integer
);


ALTER TABLE public.ventas OWNER TO v4;

--
-- Name: ventas_id_seq; Type: SEQUENCE; Schema: public; Owner: v4
--

CREATE SEQUENCE public.ventas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ventas_id_seq OWNER TO v4;

--
-- Name: ventas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: v4
--

ALTER SEQUENCE public.ventas_id_seq OWNED BY public.ventas.id;


--
-- Name: configuracion id; Type: DEFAULT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.configuracion ALTER COLUMN id SET DEFAULT nextval('public.configuracion_id_seq'::regclass);


--
-- Name: movimientos_inventario id; Type: DEFAULT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.movimientos_inventario ALTER COLUMN id SET DEFAULT nextval('public.movimientos_inventario_id_seq'::regclass);


--
-- Name: productos id; Type: DEFAULT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.productos ALTER COLUMN id SET DEFAULT nextval('public.productos_id_seq'::regclass);


--
-- Name: recibos id; Type: DEFAULT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.recibos ALTER COLUMN id SET DEFAULT nextval('public.recibos_id_seq'::regclass);


--
-- Name: turnos_caja id; Type: DEFAULT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.turnos_caja ALTER COLUMN id SET DEFAULT nextval('public.turnos_caja_id_seq'::regclass);


--
-- Name: venta_productos id; Type: DEFAULT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.venta_productos ALTER COLUMN id SET DEFAULT nextval('public.venta_productos_id_seq'::regclass);


--
-- Name: ventas id; Type: DEFAULT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.ventas ALTER COLUMN id SET DEFAULT nextval('public.ventas_id_seq'::regclass);


--
-- Data for Name: configuracion; Type: TABLE DATA; Schema: public; Owner: v4
--

COPY public.configuracion (id, clave, valor, descripcion, activo) FROM stdin;
\.


--
-- Data for Name: movimientos_inventario; Type: TABLE DATA; Schema: public; Owner: v4
--

COPY public.movimientos_inventario (id, producto_id, tipo, motivo, cantidad, referencia_id, fecha) FROM stdin;
1	1	ingreso	stock_inicial	50	\N	2026-02-16 19:44:58.397755-04
2	2	ingreso	stock_inicial	10	\N	2026-02-26 23:13:08.564675-04
3	3	ingreso	stock_inicial	2	\N	2026-02-26 23:13:56.894139-04
4	3	ingreso	compra	8	\N	2026-02-26 23:16:43.74411-04
5	2	ajuste	correccion	2	\N	2026-02-26 23:21:30.1692-04
6	2	salida	venta	1	1	2026-02-26 23:25:20.221828-04
7	3	salida	venta	2	1	2026-02-26 23:25:20.221828-04
8	4	salida	venta	1	2	2026-02-26 23:26:12.110651-04
9	4	ingreso	devolucion	1	2	2026-02-26 23:32:14.349802-04
10	3	salida	venta	3	3	2026-02-27 12:56:55.89844-04
11	4	salida	venta	1	8	2026-02-27 15:24:27.048394-04
12	5	ingreso	stock_inicial	15	\N	2026-03-07 16:16:04.033968-04
13	3	salida	venta	1	11	2026-03-07 16:17:49.677992-04
14	5	salida	venta	1	11	2026-03-07 16:17:49.677992-04
15	6	ingreso	stock_inicial	15	\N	2026-03-07 18:36:10.96542-04
16	6	salida	venta	2	12	2026-03-07 18:36:33.459033-04
17	1	salida	venta	1	12	2026-03-07 18:36:33.459033-04
18	7	ingreso	stock_inicial	5	\N	2026-03-07 18:38:47.852817-04
\.


--
-- Data for Name: productos; Type: TABLE DATA; Schema: public; Owner: v4
--

COPY public.productos (id, codigo, nombre, descripcion, precio1, precio2, precio3, precio4, stock, stock_minimo, ventas_sin_stock, ubicacion, activo, fecha_creacion, fecha_edicion) FROM stdin;
2	MOTOR-001	Motor 125cc Honda		850	820	\N	\N	7	3	0	TIENDA	t	2026-02-26 23:13:08.564675-04	2026-02-26 23:25:20.221828-04
4	FILTRO-001	Filtro de aire		35	\N	\N	\N	0	2	0	TIENDA	t	2026-02-26 23:14:41.678441-04	2026-02-27 15:24:27.048394-04
3	ACEITE-001	Aceite 4T 1L		45	\N	\N	\N	4	5	0	BODEGA	t	2026-02-26 23:13:56.894139-04	2026-03-07 16:17:49.677992-04
5	AMS001	Aceite Motor 5W30		60	\N	\N	\N	14	5	0	TIENDA	t	2026-03-07 16:16:04.033968-04	2026-03-07 16:17:49.677992-04
1	PROD001	Aceite de Motor 10W40	Aceite sintético para motor	85.5	80	75	70	49	10	0	TIENDA	t	2026-02-16 19:44:58.397755-04	2026-03-07 18:36:33.459033-04
6	CAM-022	Camara 18.50	Camara para llanta 12.20	50	45	30	\N	13	3	0	TIENDA	t	2026-03-07 18:36:10.96542-04	2026-03-07 18:36:33.459033-04
7	CAS-01	Casco	CAsco negro tamno XL	300	280	280	\N	5	1	0	TIENDA	t	2026-03-07 18:38:47.852817-04	2026-03-07 18:38:47.852817-04
\.


--
-- Data for Name: recibos; Type: TABLE DATA; Schema: public; Owner: v4
--

COPY public.recibos (id, venta_id, codigo_qr, fecha_impresion) FROM stdin;
1	1	ed98ec8c-7fd6-4f87-a6b6-7b5b2c3f2080	2026-02-26 23:25:20.242476-04
2	2	7a780e04-6fea-4612-b607-4a9a53ffac9c	2026-02-26 23:26:12.122842-04
3	3	6639294d-5810-4f76-be3b-72f7c88426ae	2026-02-27 12:56:55.91489-04
4	8	8f07b9a7-4b7f-4b9b-81ff-99b162829be3	2026-02-27 15:24:27.122824-04
5	11	55ee9967-e31d-41a6-9955-938268a87867	2026-03-07 16:17:49.69665-04
6	12	f11c7707-6a42-4966-a2f1-c5e970880677	2026-03-07 18:36:33.474407-04
\.


--
-- Data for Name: turnos_caja; Type: TABLE DATA; Schema: public; Owner: v4
--

COPY public.turnos_caja (id, fecha_apertura, fecha_cierre, monto_inicial, estado) FROM stdin;
1	2026-02-27 15:02:39.044859-04	2026-02-27 15:17:30.474088-04	100	cerrado
2	2026-02-27 15:18:23.484573-04	2026-02-27 15:18:45.113603-04	0	cerrado
3	2026-02-27 15:19:50.673625-04	2026-02-27 15:25:17.735234-04	-100	cerrado
4	2026-02-28 16:54:59.715043-04	2026-03-07 15:54:43.319044-04	200	cerrado
5	2026-03-07 15:55:20.556759-04	2026-03-07 16:18:59.93965-04	200	cerrado
6	2026-03-07 16:19:29.938598-04	2026-03-13 22:09:20.907569-04	200	cerrado
\.


--
-- Data for Name: venta_productos; Type: TABLE DATA; Schema: public; Owner: v4
--

COPY public.venta_productos (id, venta_id, producto_id, cantidad, precio_unitario) FROM stdin;
1	1	2	1	850
2	1	3	2	45
3	2	4	1	35
4	3	3	3	45
5	4	3	1	45
6	5	3	1	45
7	6	4	1	35
9	7	3	1	45
10	8	4	1	35
11	11	3	1	45
12	11	5	1	60
13	12	6	2	50
14	12	1	1	85.5
18	13	3	1	45
19	13	1	1	85.5
21	14	1	1	80
22	15	3	1	45
\.


--
-- Data for Name: ventas; Type: TABLE DATA; Schema: public; Owner: v4
--

COPY public.ventas (id, fecha, total, tipo, metodo_pago, estado, turno_id) FROM stdin;
1	2026-02-26 23:23:52.341812-04	940	normal	efectivo	completa	\N
2	2026-02-26 23:26:05.790282-04	35	sin_stock	qr	anulada	\N
3	2026-02-27 12:56:18.492127-04	135	normal	qr	completa	\N
4	2026-02-27 13:27:52.068785-04	\N	\N	\N	abierta	\N
5	2026-02-27 13:30:03.635044-04	\N	\N	\N	abierta	\N
6	2026-02-27 13:31:10.143051-04	\N	\N	\N	abierta	\N
7	2026-02-27 15:20:41.471149-04	\N	\N	\N	abierta	3
8	2026-02-27 15:24:01.971905-04	35	normal	efectivo	completa	3
9	2026-02-28 16:56:54.078885-04	\N	\N	\N	abierta	4
10	2026-03-07 16:00:02.2801-04	\N	\N	\N	abierta	5
11	2026-03-07 16:16:55.501047-04	105	normal	efectivo	completa	5
12	2026-03-07 18:36:18.403046-04	185.5	normal	qr	completa	6
13	2026-03-07 18:39:16.678411-04	\N	\N	\N	abierta	6
14	2026-03-07 22:24:15.467018-04	\N	\N	\N	abierta	6
15	2026-03-13 22:08:59.897786-04	\N	\N	\N	abierta	6
\.


--
-- Name: configuracion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: v4
--

SELECT pg_catalog.setval('public.configuracion_id_seq', 1, false);


--
-- Name: movimientos_inventario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: v4
--

SELECT pg_catalog.setval('public.movimientos_inventario_id_seq', 18, true);


--
-- Name: productos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: v4
--

SELECT pg_catalog.setval('public.productos_id_seq', 7, true);


--
-- Name: recibos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: v4
--

SELECT pg_catalog.setval('public.recibos_id_seq', 6, true);


--
-- Name: turnos_caja_id_seq; Type: SEQUENCE SET; Schema: public; Owner: v4
--

SELECT pg_catalog.setval('public.turnos_caja_id_seq', 6, true);


--
-- Name: venta_productos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: v4
--

SELECT pg_catalog.setval('public.venta_productos_id_seq', 22, true);


--
-- Name: ventas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: v4
--

SELECT pg_catalog.setval('public.ventas_id_seq', 15, true);


--
-- Name: configuracion configuracion_pkey; Type: CONSTRAINT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.configuracion
    ADD CONSTRAINT configuracion_pkey PRIMARY KEY (id);


--
-- Name: movimientos_inventario movimientos_inventario_pkey; Type: CONSTRAINT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.movimientos_inventario
    ADD CONSTRAINT movimientos_inventario_pkey PRIMARY KEY (id);


--
-- Name: productos productos_pkey; Type: CONSTRAINT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_pkey PRIMARY KEY (id);


--
-- Name: recibos recibos_codigo_qr_key; Type: CONSTRAINT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.recibos
    ADD CONSTRAINT recibos_codigo_qr_key UNIQUE (codigo_qr);


--
-- Name: recibos recibos_pkey; Type: CONSTRAINT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.recibos
    ADD CONSTRAINT recibos_pkey PRIMARY KEY (id);


--
-- Name: turnos_caja turnos_caja_pkey; Type: CONSTRAINT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.turnos_caja
    ADD CONSTRAINT turnos_caja_pkey PRIMARY KEY (id);


--
-- Name: venta_productos venta_productos_pkey; Type: CONSTRAINT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.venta_productos
    ADD CONSTRAINT venta_productos_pkey PRIMARY KEY (id);


--
-- Name: ventas ventas_pkey; Type: CONSTRAINT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_pkey PRIMARY KEY (id);


--
-- Name: ix_configuracion_clave; Type: INDEX; Schema: public; Owner: v4
--

CREATE UNIQUE INDEX ix_configuracion_clave ON public.configuracion USING btree (clave);


--
-- Name: ix_configuracion_id; Type: INDEX; Schema: public; Owner: v4
--

CREATE INDEX ix_configuracion_id ON public.configuracion USING btree (id);


--
-- Name: ix_movimientos_inventario_id; Type: INDEX; Schema: public; Owner: v4
--

CREATE INDEX ix_movimientos_inventario_id ON public.movimientos_inventario USING btree (id);


--
-- Name: ix_productos_codigo; Type: INDEX; Schema: public; Owner: v4
--

CREATE UNIQUE INDEX ix_productos_codigo ON public.productos USING btree (codigo);


--
-- Name: ix_productos_id; Type: INDEX; Schema: public; Owner: v4
--

CREATE INDEX ix_productos_id ON public.productos USING btree (id);


--
-- Name: ix_recibos_id; Type: INDEX; Schema: public; Owner: v4
--

CREATE INDEX ix_recibos_id ON public.recibos USING btree (id);


--
-- Name: ix_turnos_caja_id; Type: INDEX; Schema: public; Owner: v4
--

CREATE INDEX ix_turnos_caja_id ON public.turnos_caja USING btree (id);


--
-- Name: ix_venta_productos_id; Type: INDEX; Schema: public; Owner: v4
--

CREATE INDEX ix_venta_productos_id ON public.venta_productos USING btree (id);


--
-- Name: ix_ventas_id; Type: INDEX; Schema: public; Owner: v4
--

CREATE INDEX ix_ventas_id ON public.ventas USING btree (id);


--
-- Name: movimientos_inventario movimientos_inventario_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.movimientos_inventario
    ADD CONSTRAINT movimientos_inventario_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id);


--
-- Name: recibos recibos_venta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.recibos
    ADD CONSTRAINT recibos_venta_id_fkey FOREIGN KEY (venta_id) REFERENCES public.ventas(id);


--
-- Name: venta_productos venta_productos_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.venta_productos
    ADD CONSTRAINT venta_productos_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id);


--
-- Name: venta_productos venta_productos_venta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.venta_productos
    ADD CONSTRAINT venta_productos_venta_id_fkey FOREIGN KEY (venta_id) REFERENCES public.ventas(id);


--
-- Name: ventas ventas_turno_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: v4
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_turno_id_fkey FOREIGN KEY (turno_id) REFERENCES public.turnos_caja(id);


--
-- PostgreSQL database dump complete
--

\unrestrict elclamNA7HNSkdTlaKXV1FBwWFw78Fe1xyx6hHYhxBSMFC7GudqPAgd7deA1oKc

